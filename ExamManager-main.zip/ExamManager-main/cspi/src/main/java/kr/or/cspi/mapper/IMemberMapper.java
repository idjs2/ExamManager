package kr.or.cspi.mapper;

import java.util.List;

import kr.or.cspi.vo.MemberVO;

public interface IMemberMapper {

	List<MemberVO> memberList();

}
