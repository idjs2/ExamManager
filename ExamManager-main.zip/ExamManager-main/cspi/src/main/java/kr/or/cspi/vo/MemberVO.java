package kr.or.cspi.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String memId;
	private String posNo;
	private String depNo;
	private String memName;
	private String memPw;
}
