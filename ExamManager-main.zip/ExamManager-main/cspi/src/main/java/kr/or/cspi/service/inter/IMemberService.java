package kr.or.cspi.service.inter;

import java.util.List;

import kr.or.cspi.vo.MemberVO;

public interface IMemberService {

	List<MemberVO> memberList();

}
