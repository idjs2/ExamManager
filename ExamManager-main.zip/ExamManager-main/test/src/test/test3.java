package test;

public class test3 {
public static void main(String[] args) {

	//충돌 확인중...
	for (int i = 0; i < args.length; i++) {
		System.out.println("안녕하세요");
	}

	System.out.println("Hello");
	System.out.println("�ȳļ���");
}
}
