package test;

public class test1 {
	public static void main(String[] args) {
		int i = 1;
		float f = 1.1f;
		double d = 1.2;
		boolean b = true;
		char c = 'a';
		
		System.out.println(i);
		System.out.println(f);
		System.out.println(d);
		System.out.println(b);
		System.out.println(c);
	}
}
